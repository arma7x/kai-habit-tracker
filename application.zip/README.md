# Habit Tracker
> Habit Tracker is an app to track your daily habits or if you want to stop yourself from bad habits

[MIT](https://opensource.org/licenses/MIT)
